
# Observer AI Agent Framework

A multi-agent reasoning architecture implementing a Higher-Order Observer (HOO) meta-cognitive layer for synthesising diverse reasoning streams.

## Concept

Parallel reasoning agents analyse a prompt from different perspectives. A Higher-Order Observer synthesises the outputs.

Agents:

- Analytical
- Creative
- Critical
- Systems Thinking
- Pragmatic

## Architecture

```mermaid
flowchart TD

User[User Prompt]
UI[Web Interface]
API[FastAPI Gateway]
ORCH[Observer Orchestrator]

A1[Analytical Agent]
A2[Creative Agent]
A3[Critical Agent]
A4[Systems Agent]
A5[Pragmatic Agent]

HOO[Higher Order Observer]
OUT[Structured Response]

User --> UI
UI --> API
API --> ORCH

ORCH --> A1
ORCH --> A2
ORCH --> A3
ORCH --> A4
ORCH --> A5

A1 --> HOO
A2 --> HOO
A3 --> HOO
A4 --> HOO
A5 --> HOO

HOO --> OUT
OUT --> UI
```

## Running

Install dependencies

pip install fastapi uvicorn

Run server

uvicorn backend.api.server:app --reload

