
from fastapi import FastAPI
from pydantic import BaseModel

from backend.core.orchestrator import run_agents
from backend.core.observer import synthesise

app = FastAPI()

class Prompt(BaseModel):
    prompt: str

@app.post("/observe")
def observe(p: Prompt):

    streams = run_agents(p.prompt)
    result = synthesise(streams)

    return result
