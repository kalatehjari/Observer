
def run(prompt):
    return {
        "lens": "Pragmatic",
        "reasoning": "Pragmatic perspective on: " + prompt,
        "concepts": []
    }
