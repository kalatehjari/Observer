
def run(prompt):
    return {
        "lens": "Systems Thinking",
        "reasoning": "Systems Thinking perspective on: " + prompt,
        "concepts": []
    }
