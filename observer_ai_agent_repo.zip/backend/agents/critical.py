
def run(prompt):
    return {
        "lens": "Critical",
        "reasoning": "Critical perspective on: " + prompt,
        "concepts": []
    }
