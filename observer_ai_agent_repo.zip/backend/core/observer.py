
def synthesise(streams):

    concepts = []
    reasoning = []

    for s in streams:
        reasoning.append(s["reasoning"])
        concepts.extend(s["concepts"])

    return {
        "synthesis": "Combined reasoning from multiple lenses",
        "consensus_concepts": list(set(concepts)),
        "streams": streams
    }
