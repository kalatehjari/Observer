
from backend.agents import analytical, creative, critical, systems, pragmatic

def run_agents(prompt):

    results = []

    results.append(analytical.run(prompt))
    results.append(creative.run(prompt))
    results.append(critical.run(prompt))
    results.append(systems.run(prompt))
    results.append(pragmatic.run(prompt))

    return results
